﻿using SocialMediaAppServer.Models.DTOs;

namespace SocialMediaAppServer.Models.Responses.UserResponses
{
    public class GetUserPersonalInfoResponse : PersonalUserInfoDTO
    {
    }
}
