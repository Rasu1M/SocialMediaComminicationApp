﻿using SocialMediaAppServer.Models.DTOs;
using SocialMediaAppServer.Models.Strctures;

namespace SocialMediaAppServer.Models.Responses.CommentResponses
{
    public class GetCommentsForTheEntryResponse
    {
        public EntryDTO Entry { get; set; }

        public List<CommentsStructure> Comments { get; set; } = new List<CommentsStructure>();
    }
}
