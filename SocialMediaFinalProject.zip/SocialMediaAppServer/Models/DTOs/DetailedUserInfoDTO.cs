﻿namespace SocialMediaAppServer.Models.DTOs
{
    public class DetailedUserInfoDTO : UserInfoDTO
    {
        public int CommentsUpVotes { get; set; }

        public int CommentsDownVotes { get; set; }

        public int EntriesUpVotes { get; set; }

        public int EntriesDownVotes { get; set; }
        public int TotalEntries { get; set; }

        public int TotalComments { get; set; }
    }
}
