﻿namespace SocialMediaAppServer.Models.Enums
{
    public enum VoteType
    {
        None = 0,
        UpVote = 1,
        DownVote = -1,
    }
}
