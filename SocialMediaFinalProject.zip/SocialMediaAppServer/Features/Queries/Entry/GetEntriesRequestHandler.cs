﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.DTOs;
using SocialMediaAppServer.Models.Enums;
using SocialMediaAppServer.Models.Responses.EntryResponses;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Queries.Entry
{
    public class GetEntriesRequestHandler : IRequestHandler<GetEntriesRequest, GetEntriesResponse>
    {
        private readonly IReadGenericRepository<Models.Domain.Entry> _readRepository;

        public GetEntriesRequestHandler(IReadGenericRepository<Models.Domain.Entry> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<GetEntriesResponse> Handle(GetEntriesRequest request, CancellationToken cancellationToken)
        {
            List<Models.Domain.Entry> entries;

            // IF USER DONT CHOOSE A FILTER
            if(request.WriterType == WriterType.All && request.EntryType == EntryTypes.All)
            {
                entries = _readRepository.AsQueryable().Include(x => x.User)
                    .Include(x => x.EntryVotes).Include(x => x.Comments).Include(x => x.CommentVotes).ToList();
            }
            // IF USER CHOOSE ONLY ENTRYTYPE FILTER
            else if (request.WriterType == WriterType.All)
            {
                entries = _readRepository.AsQueryable()
                    .Where(x => x.EntryType == request.EntryType).Include(x => x.User)
                   .Include(x => x.EntryVotes).Include(x => x.Comments).Include(x => x.CommentVotes).ToList();
            }
            // IF USER CHOOSE ONLY WRITERTYPE FILTER
            else if (request.EntryType == EntryTypes.All)
            {
                bool IsWriterSystem = request.WriterType == WriterType.System ? true : false;

                entries = _readRepository.AsQueryable()
                    .Where(x => x.IsWritedBySystem == IsWriterSystem).Include(x => x.User)
                   .Include(x => x.EntryVotes).Include(x => x.Comments).Include(x => x.CommentVotes).ToList();
            }
            // IF USER CHOOSE both FILTERS
            else
            {
                bool IsWriterSystem = request.WriterType == WriterType.System ? true : false;

                entries = _readRepository.AsQueryable()
                    .Where(x => x.IsWritedBySystem == IsWriterSystem && x.EntryType == request.EntryType)
                    .Include(x => x.User).Include(x => x.EntryVotes)
                    .Include(x => x.Comments).Include(x => x.CommentVotes).ToList();
            }

            var response = new GetEntriesResponse();

            if (entries != null && entries.Count > 0)
            {

                // ADD ENTRIES TO THE RESPONSE
                foreach (var entry in entries)
                {
                    int upVotes = 0;
                    int downVotes = 0;
                    int commentsUpVotes = 0;
                    int commentsDownVotes = 0;

                    if (entry.EntryVotes != null && entry.EntryVotes.Count > 0)
                    {

                        // ADD ENTRYVOTES OF EVERY ENTRY TO RESPONSE
                        foreach (var entryVote in entry.EntryVotes)
                        {
                            if (entryVote.VoteType == VoteType.UpVote)
                            {
                                upVotes++;
                            }

                            if (entryVote.VoteType == VoteType.DownVote)
                            {
                                downVotes++;
                            }

                        }
                    }

                    if (entry.CommentVotes != null && entry.CommentVotes.Count > 0)
                    {

                        //ADD TOTALVOTES FOR COMMENTS OF EVERY ENTRY TO RESPONSE
                        foreach (var commentVote in entry.CommentVotes)
                        {
                            if (commentVote.VoteType == VoteType.UpVote)
                            {
                                commentsUpVotes++;
                            }

                            if (commentVote.VoteType == VoteType.DownVote)
                            {
                                commentsDownVotes++;
                            }

                        }
                    }

                    // CREATE ENTRYDTO FOR EVERY ENTRY
                    var entryDTO = new EntryDTO()
                    {
                        EntryID = entry.ID,
                        EntryTitle = entry.EntryTitle,
                        EntryTopic = entry.EntryTopic,
                        UpVotes = upVotes,
                        DownVotes = downVotes,
                        CommentsUpVotes = commentsUpVotes,
                        CommentsDownVotes = commentsDownVotes,
                        TotalComments = entry.Comments.Count(),
                        UserInfo = new UserInfoDTO()
                        {
                            UserID = entry.User.ID,
                            FullName = entry.User.FullName,
                        }

                    };

                    response.Entries.Add(entryDTO);
                }
            }

            return response;
        }
    }
}
