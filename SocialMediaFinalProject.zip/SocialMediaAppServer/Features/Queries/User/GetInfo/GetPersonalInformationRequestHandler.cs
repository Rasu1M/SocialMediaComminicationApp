﻿using Blazored.LocalStorage;
using MediatR;
using Microsoft.EntityFrameworkCore;
using MindMaze.Infrastructure.infrastructure.Repositories;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.Responses.UserResponses;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Queries.User.GetInfo
{
    public class GetPersonalInformationRequestHandler : IRequestHandler<GetPersonalInformationRequest, GetUserPersonalInfoResponse>
    {
        private readonly IReadGenericRepository<Users> _readRepository;

        public GetPersonalInformationRequestHandler(IReadGenericRepository<Users> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<GetUserPersonalInfoResponse> Handle(GetPersonalInformationRequest request, CancellationToken cancellationToken)
        {


           

            Users User = _readRepository.AsQueryable().Where(x => x.ID == request.UserID)
                .Include(x => x.Comments).ThenInclude(x => x.CommentVotes.Where(x => x.UserID == request.UserID))
                .Include(x => x.Entries).ThenInclude(x => x.CommentVotes.Where(x => x.UserID == request.UserID)).FirstOrDefault();



            if (User == null)
            {
                return new GetUserPersonalInfoResponse();
            }

            var response = new GetUserPersonalInfoResponse()
            {
                UserID = User.ID,
                FullName = User.FullName,
                Email = User.Email,
                TotalEntries = User.Entries.Count(),
                TotalComments = User.Comments.Count()
            };

            if (User.Entries != null && User.Entries.Count() > 0)
            {

                foreach (Models.Domain.Entry entry in User.Entries)
                {
                    if (entry.EntryVotes != null && entry.EntryVotes.Count > 0)
                    {

                        foreach (Models.Domain.EntryVote entryVote in entry.EntryVotes)
                        {
                            if (entryVote.VoteType == Models.Enums.VoteType.UpVote) response.EntriesUpVotes++;
                            else response.EntriesDownVotes++;
                        }
                    }
                }
            }

            if (User.Comments != null && User.Comments.Count() > 0)
            {

                foreach (Models.Domain.Comment comment in User.Comments)
                {
                    if (comment.CommentVotes != null && comment.CommentVotes.Count() > 0)
                    {
                        foreach (Models.Domain.CommentVote commentVote in comment.CommentVotes)
                        {
                            if (commentVote.VoteType == Models.Enums.VoteType.UpVote) response.CommentsUpVotes++;
                            else response.CommentsDownVotes++;
                        }
                    }
                }
            }

            return response;

        }
    }
}
