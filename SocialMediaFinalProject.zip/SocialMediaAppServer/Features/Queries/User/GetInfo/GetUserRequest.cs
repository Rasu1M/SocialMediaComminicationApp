﻿using MediatR;
using SocialMediaAppServer.Models.Responses.UserResponses;

namespace SocialMediaAppServer.Features.Queries.User.GetInfo
{
    public class GetUserRequest : IRequest<GetDetailedUserInfoResponse>
    {
        public Guid UserID { get; set; }
    }
}
