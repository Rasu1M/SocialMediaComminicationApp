﻿using MediatR;
using SocialMediaAppServer.Models.Responses.UserResponses;

namespace SocialMediaAppServer.Features.Queries.User.GetInfo
{
    public class GetPersonalInformationRequest : IRequest<GetUserPersonalInfoResponse>
    {
        public Guid UserID { get; set; }
    }
}
