﻿using Blazored.LocalStorage;
using MediatR;
using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.Responses.UserResponses;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Queries.User.GetInfo
{
    public class GetUserRequestHandler : IRequestHandler<GetUserRequest, GetDetailedUserInfoResponse>
    {

        private readonly IReadGenericRepository<Models.Domain.Users> _readRepository;

        public GetUserRequestHandler(IReadGenericRepository<Users> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<GetDetailedUserInfoResponse> Handle(GetUserRequest request, CancellationToken cancellationToken)
        {
            Users User = _readRepository.AsQueryable().Where(x => x.ID == request.UserID)
                .Include(x => x.Comments).ThenInclude(x => x.CommentVotes.Where(x => x.UserID == request.UserID))
                .Include(x => x.Entries).ThenInclude(x => x.CommentVotes.Where(x => x.UserID == request.UserID))
                .FirstOrDefault();

            if (User == null)
            {
                return new GetDetailedUserInfoResponse();
            }

            var response = new GetDetailedUserInfoResponse()
            {
                UserID = User.ID,
                FullName = User.FullName,
                TotalEntries = User.Entries.Count(),
                TotalComments = User.Comments.Count()
            };

            if (User.Entries != null && User.Entries.Count() > 0)
            {

                foreach (Models.Domain.Entry entry in User.Entries)
                {
                    foreach (Models.Domain.EntryVote entryVote in entry.EntryVotes)
                    {
                        if (entryVote.VoteType == Models.Enums.VoteType.UpVote) response.EntriesUpVotes++;
                        else response.EntriesDownVotes++;
                    }
                }
            }

            if (User.Comments != null && User.Comments.Count() > 0)
            {

                foreach (Models.Domain.Comment comment in User.Comments)
                {
                    foreach (Models.Domain.CommentVote commentVote in comment.CommentVotes)
                    {
                        if (commentVote.VoteType == Models.Enums.VoteType.UpVote) response.CommentsUpVotes++;
                        else response.CommentsDownVotes++;
                    }
                }
            }

            return response;

        }
    }
}
