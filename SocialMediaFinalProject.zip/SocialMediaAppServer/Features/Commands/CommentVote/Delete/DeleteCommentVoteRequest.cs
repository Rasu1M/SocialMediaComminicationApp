﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.CommentVote.Delete
{
    public class DeleteCommentVoteRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
        public Guid CommentID { get; set; }
    }
}
