﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Features.Commands.Comment.Create;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.Models;

namespace SocialMediaAppServer.Features.Commands.CommentVote.Create
{
    public class CreateCommentVoteRequestHandler : IRequestHandler<CreateCommentVoteRequest, bool>
    {
        private readonly IWriteGenericRepository<Models.Domain.CommentVote> _writeRepository;
        private readonly IReadGenericRepository<Models.Domain.CommentVote> _readRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateCommentVoteRequestHandler(IWriteGenericRepository<Models.Domain.CommentVote> writeRepository,
                                               IReadGenericRepository<Models.Domain.CommentVote> readRepository,
                                               IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(CreateCommentVoteRequest request, CancellationToken cancellationToken)
        {

            if (await _readRepository.Getasync(x => x.UserID == request.UserID
            && x.CommentID == request.CommentID) != null)
            {
                return false;
            }
            
            Models.Domain.CommentVote commentvote = new Models.Domain.CommentVote()
            {
                UserID = request.UserID,
                EntryID = request.EntryID,
                CommentID = request.CommentID,
                VoteType = request.VoteType
            };

            await _writeRepository.Addasync(commentvote);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
