﻿using MediatR;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using Blazored.LocalStorage;

namespace SocialMediaAppServer.Features.Commands.Comment.Create
{


    public class CreateCommentRequestHandler : IRequestHandler<CreateCommentRequest, bool>
    {
        private readonly IWriteGenericRepository<Models.Domain.Comment> _writeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateCommentRequestHandler(IWriteGenericRepository<Models.Domain.Comment> writeRepository,
                                           IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(CreateCommentRequest request, CancellationToken cancellationToken)
        {
            

            Models.Domain.Comment comment = new Models.Domain.Comment()
            {
                UserID = request.UserID,
                EntryID = request.EntryID,
                ParentCommentID = request.ParentCommentID,
                CommentString = request.CommentString
            };

            await _writeRepository.Addasync(comment);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
