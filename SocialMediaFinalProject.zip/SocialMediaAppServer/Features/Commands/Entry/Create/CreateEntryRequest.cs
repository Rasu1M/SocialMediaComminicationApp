﻿using MediatR;
using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Features.Commands.Entry.Create
{
    public class CreateEntryRequest : IRequest<Guid>
    {
        public Guid UserID { get; set; }
        public string EntryTitle { get; set; }

        public string EntryTopic { get; set; }

        public bool IsWritedBySystem { get; set; }

        public EntryTypes EntryType { get; set; }
    }
}
