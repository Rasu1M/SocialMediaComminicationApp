﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Features.Commands.Comment.Create;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.Features.Commands.Entry.Create
{
    public class CreateEntryRequestHandler : IRequestHandler<CreateEntryRequest, Guid>
    {
        private readonly IWriteGenericRepository<Models.Domain.Entry> _writeRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateEntryRequestHandler(IWriteGenericRepository<Models.Domain.Entry> writeRepository,
                                         IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<Guid> Handle(CreateEntryRequest request, CancellationToken cancellationToken)
        {
            
            Models.Domain.Entry entry = new Models.Domain.Entry()
            {
                UserID = request.UserID,
                EntryTitle = request.EntryTitle,
                EntryTopic = request.EntryTopic,
                IsWritedBySystem = request.IsWritedBySystem,
                EntryType = request.EntryType
            };

            await _writeRepository.Addasync(entry);

            if (await _unitOfWork.SaveChangesAsync() == 1) return entry.ID;

            return Guid.Empty;

        }
    }
}
