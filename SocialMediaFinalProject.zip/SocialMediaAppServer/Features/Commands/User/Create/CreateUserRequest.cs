﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.User.Create
{
    public class CreateUserRequest : IRequest<Guid>
    {
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
