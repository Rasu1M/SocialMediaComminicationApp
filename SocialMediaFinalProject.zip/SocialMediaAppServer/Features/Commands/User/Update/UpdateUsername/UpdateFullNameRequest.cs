﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.User.Update.UpdateUsername
{
    public class UpdateFullNameRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
        public string NewFullName { get; set;}
    }
}
