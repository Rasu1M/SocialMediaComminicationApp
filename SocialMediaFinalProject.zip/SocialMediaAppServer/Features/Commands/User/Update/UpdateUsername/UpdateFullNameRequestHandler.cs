﻿using MediatR;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using Blazored.LocalStorage;

namespace SocialMediaAppServer.Features.Commands.User.Update.UpdateUsername
{


    public class UpdateFullNameRequestHandler : IRequestHandler<UpdateFullNameRequest, bool>
    {
        private readonly IGenericRepository<Users> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public UpdateFullNameRequestHandler(IGenericRepository<Users> genericRepository, IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(UpdateFullNameRequest request, CancellationToken cancellationToken)
        {
            
            var User = await _genericRepository.GetByIDAsync(request.UserID);

            if (User == null)
            {
                return false;
            }

            User.FullName = request.NewFullName;

            _genericRepository.UpdateEntity(User);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;
        }
    }
}
