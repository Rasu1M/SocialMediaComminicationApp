﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.User.Update.UpdatePassWord
{
    public class UpdatePassWordRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }

        public string OldPassWord { get; set; }

        public string NewPassWord { get; set; }
    }
}
