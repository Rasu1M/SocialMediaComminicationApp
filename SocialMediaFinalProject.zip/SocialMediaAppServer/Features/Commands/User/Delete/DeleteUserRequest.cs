﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.User.Delete
{
    public class DeleteUserRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
    }
}
