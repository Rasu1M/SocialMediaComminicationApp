﻿using MediatR;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using Blazored.LocalStorage;

namespace SocialMediaAppServer.Features.Commands.User.Delete
{
    public class SetUserDeletionRequestHandler : IRequestHandler<SetUserDeletionRequest, bool>
    {
        private readonly IGenericRepository<Users> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public SetUserDeletionRequestHandler(IGenericRepository<Users> genericRepository, IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(SetUserDeletionRequest request, CancellationToken cancellationToken)
        {
           

            Users user = await _genericRepository.GetByIDAsync(request.UserID);

            user.IsDeleted = true;

            _genericRepository.UpdateEntity(user);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;
        }
    }
}
