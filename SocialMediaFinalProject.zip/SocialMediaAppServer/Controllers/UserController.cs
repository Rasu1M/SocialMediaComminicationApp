﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialMediaAppServer.Features.Commands.Entry.Create;
using SocialMediaAppServer.Features.Queries.User.GetInfo;
using SocialMediaAppServer.Models.Responses.UserResponses;

namespace SocialMediaAppServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;

        public UserController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Route("/GetDetailedUserInfo")]
        public async Task<GetDetailedUserInfoResponse> GetDetailedUserInfo([FromQuery] GetUserRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpGet]
        [Route("/GetPersonalInformation")]
        public async Task<GetUserPersonalInfoResponse> GetPersonalInformation([FromQuery] GetPersonalInformationRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

    }
}
