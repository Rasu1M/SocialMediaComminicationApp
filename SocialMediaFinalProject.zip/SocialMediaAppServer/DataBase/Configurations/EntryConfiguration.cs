﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.DataBase.Configurations
{
    public class EntryConfiguration : BaseConfiguration<Entry>
    {

        public override void Configure(EntityTypeBuilder<Entry> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(Entry));

            builder.HasOne(x => x.User).WithMany(x => x.Entries)
           .HasForeignKey(x => x.UserID).HasConstraintName("FK_UserToEntry").OnDelete(DeleteBehavior.NoAction);
        }
    }
}
