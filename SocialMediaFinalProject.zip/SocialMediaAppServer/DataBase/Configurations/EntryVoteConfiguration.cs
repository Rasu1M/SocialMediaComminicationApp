﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.DataBase.Configurations
{
    public class EntryVoteConfiguration : BaseConfiguration<EntryVote>
    {
        public override void Configure(EntityTypeBuilder<EntryVote> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(EntryVote));

            builder.HasOne(x => x.User).WithMany(x => x.EntryVotes)
                .HasForeignKey(x => x.UserID).HasConstraintName("FK_UserToEntryVote").OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(x => x.Entry).WithMany(x => x.EntryVotes)
                .HasForeignKey(x => x.EntryID).HasConstraintName("FK_EntryToEntryVote").OnDelete(DeleteBehavior.NoAction);
        }
    }
}
