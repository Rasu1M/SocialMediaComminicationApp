﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.DataBase.Configurations
{
    public class CommentConfiguration : BaseConfiguration<Comment>
    {
        public override void Configure(EntityTypeBuilder<Comment> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(Comment));

            builder.HasOne(x => x.User).WithMany(x => x.Comments)
           .HasForeignKey(x => x.UserID).HasConstraintName("FK_UserToComment").OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(x => x.Entry).WithMany(x => x.Comments)
           .HasForeignKey(x => x.EntryID).HasConstraintName("FK_EntryToComment").OnDelete(DeleteBehavior.NoAction);
        }
    }
}
