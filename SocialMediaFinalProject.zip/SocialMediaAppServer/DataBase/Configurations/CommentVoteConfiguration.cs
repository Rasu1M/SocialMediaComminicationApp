﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.DataBase.Configurations
{
    public class CommentVoteConfiguration : BaseConfiguration<CommentVote>
    {
        public override void Configure(EntityTypeBuilder<CommentVote> builder)
        {
            base.Configure(builder);

            builder.ToTable(nameof(CommentVote));

            builder.HasOne(x => x.User).WithMany(x => x.CommentVotes)
                .HasForeignKey(x => x.UserID).HasConstraintName("FK_UserToCommentVote")
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(x => x.Comment).WithMany(x => x.CommentVotes)
                .HasForeignKey(x => x.CommentID).HasConstraintName("FK_CommentToCommentVote")
                .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(x => x.Entry).WithMany(x => x.CommentVotes)
                .HasForeignKey(x => x.EntryID).HasConstraintName("FK_EntryToCommentVote")
                .OnDelete(DeleteBehavior.NoAction);
        }
    }
}
