﻿// Get the popup elements
const changeUsernamePopup = document.getElementById("changeUsernamePopup");
const changePasswordPopup = document.getElementById("changePasswordPopup");

// Get the button that opens the popup
const changeUsernameBtn = document.getElementById("changeUsernameBtn");
const changePasswordBtn = document.getElementById("changePasswordBtn");

// Get the <span> element that closes the popup
const closeChangeUsernamePopup = document.getElementById("closeChangeUsernamePopup");
const closeChangePasswordPopup = document.getElementById("closeChangePasswordPopup");

// When the user clicks the button, open the popup
changeUsernameBtn.onclick = function () {
    changeUsernamePopup.style.display = "block";
}
changePasswordBtn.onclick = function () {
    changePasswordPopup.style.display = "block";
}

// When the user clicks on <span> (x), close the popup
closeChangeUsernamePopup.onclick = function () {
    changeUsernamePopup.style.display = "none";
}
closeChangePasswordPopup.onclick = function () {
    changePasswordPopup.style.display = "none";
}

// When the user clicks anywhere outside of the popup, close it
window.onclick = function (event) {
    if (event.target == changeUsernamePopup) {
        changeUsernamePopup.style.display = "none";
    }
    if (event.target == changePasswordPopup) {
        changePasswordPopup.style.display = "none";
    }
}
