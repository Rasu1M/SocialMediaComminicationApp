﻿using SocialMediaClient.Models.DTOs;

namespace SocialMediaClient.Models.Responses
{
    public class GetEntriesResponse
    {
        public List<EntryDTO> Entries { get; set; } = new List<EntryDTO>();
    }
}
