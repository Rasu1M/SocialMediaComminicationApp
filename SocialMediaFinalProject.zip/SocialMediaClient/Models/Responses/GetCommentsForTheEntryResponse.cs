﻿using SocialMediaClient.Models.DTOs;
using SocialMediaClient.Models.Structures;

namespace SocialMediaClient.Models.Responses
{
    public class GetCommentsForTheEntryResponse
    {
        public EntryDTO Entry { get; set; }

        public List<CommentsStructure> Comments { get; set; } = new List<CommentsStructure> { };
    }
}
