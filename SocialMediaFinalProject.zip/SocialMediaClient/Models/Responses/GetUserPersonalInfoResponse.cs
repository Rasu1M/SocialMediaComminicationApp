﻿namespace SocialMediaClient.Models.Responses
{
    public class GetUserPersonalInfoResponse
    {
        public string Email { get; set; }

        public string FullName { get; set; }

        public int CommentsUpVotes { get; set; }

        public int CommentsDownVotes { get; set; }

        public int EntriesUpVotes { get; set; }

        public int EntriesDownVotes { get; set; }
        public int TotalEntries { get; set; }

        public int TotalComments { get; set; }
    }
}
