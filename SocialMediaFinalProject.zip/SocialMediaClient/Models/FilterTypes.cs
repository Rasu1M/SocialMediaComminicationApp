﻿using SocialMediaClient.Models.Enums;

namespace SocialMediaClient.Models
{
    public class Filtertypes
    {
        public EntryTypes FilterEntryType { get; set; }
        public WriterType FilterWriterType { get; set; }
    }
}
