﻿using SocialMediaClient.Models.DTOs;

namespace SocialMediaClient.Models.Structures
{
    public struct CommentsStructure
    {
        public CommentDTO Comment { get; set; }

        public List<CommentsStructure> ChildrenComments { get; set; }
    }

}
