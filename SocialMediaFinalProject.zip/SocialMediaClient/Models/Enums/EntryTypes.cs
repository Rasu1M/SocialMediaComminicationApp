﻿namespace SocialMediaClient.Models.Enums
{
    public enum EntryTypes
    {
        All = 0,
        Sport = 1,
        Movies = 2,
        Series = 3,
        Fictional_Characters = 4
    }
}
