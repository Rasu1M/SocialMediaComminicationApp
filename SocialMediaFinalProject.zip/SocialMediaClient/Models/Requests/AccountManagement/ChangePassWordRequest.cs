﻿namespace SocialMediaClient.Models.Requests.AccountManagement
{
    public class ChangePassWordRequest
    {
        public Guid UserID { get; set; }

        public string OldPassWord {  get; set; }

        public string NewPassWord { get; set;}
    }
}
