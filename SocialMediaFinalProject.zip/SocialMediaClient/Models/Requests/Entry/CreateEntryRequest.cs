﻿using SocialMediaClient.Models.Enums;

namespace SocialMediaClient.Models.Requests.Entry
{
    public class CreateEntryRequest
    {
        public Guid UserID { get; set; }
        public string EntryTitle { get; set; }

        public string EntryTopic { get; set; }

        public bool IsWritedBySystem { get; set; }

        public EntryTypes EntryType { get; set; }
    }
}
