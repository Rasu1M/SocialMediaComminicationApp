﻿namespace SocialMediaClient.Models.Requests.CommentVote
{
    public class DeleteCommentVoteRequest
    {
        public Guid UserID { get; set; }
        public Guid CommentID { get; set; }
    }
}
