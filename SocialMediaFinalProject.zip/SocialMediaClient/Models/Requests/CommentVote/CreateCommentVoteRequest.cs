﻿using SocialMediaClient.Models.Enums;

namespace SocialMediaClient.Models.Requests.CommentVote
{
    public class CreateCommentVoteRequest
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
        public Guid CommentID { get; set; }
        public VoteType VoteType { get; set; }
    }
}
