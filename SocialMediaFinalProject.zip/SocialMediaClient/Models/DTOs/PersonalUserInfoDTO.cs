﻿namespace SocialMediaClient.Models.DTOs
{
    public class PersonalUserInfoDTO : DetailedUserInfoDTO
    {
        public string Email { get; set; }
    }
}
