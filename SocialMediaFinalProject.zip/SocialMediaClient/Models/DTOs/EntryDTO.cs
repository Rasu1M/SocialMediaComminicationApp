﻿namespace SocialMediaClient.Models.DTOs
{
    public class EntryDTO
    {
        public Guid EntryID { get; set; }

        public string EntryTitle { get; set; }

        public string EntryTopic { get; set; }

        public int UpVotes { get; set; }

        public int DownVotes { get; set; }

        public int CommentsUpVotes { get; set; }

        public int CommentsDownVotes { get; set; }

        public int TotalComments { get; set; }

        public UserInfoDTO UserInfo { get; set; } = new UserInfoDTO();
    }
}
