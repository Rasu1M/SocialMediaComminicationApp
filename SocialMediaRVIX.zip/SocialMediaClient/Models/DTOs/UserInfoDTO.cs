﻿namespace SocialMediaClient.Models.DTOs
{
    public class UserInfoDTO
    {
        public Guid UserID { get; set; }

        public string FullName { get; set; }

    }
}
