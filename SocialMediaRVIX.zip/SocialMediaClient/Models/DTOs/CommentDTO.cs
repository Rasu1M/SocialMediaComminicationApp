﻿namespace SocialMediaClient.Models.DTOs
{
    public class CommentDTO
    {
        public Guid CommentID { get; set; }

        public Guid UserID { get; set; }

        public Guid EntryID { get; set; }

        public Guid ParentCommentID { get; set; }

        public string CommentString { get; set; }

        public int UpVotes { get; set; } = 0;

        public int DownVotes { get; set; } = 0;

        public UserInfoDTO UserInfo { get; set; } = new UserInfoDTO();
    }
}
