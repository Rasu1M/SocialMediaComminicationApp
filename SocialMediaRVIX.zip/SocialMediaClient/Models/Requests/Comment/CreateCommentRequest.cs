﻿namespace SocialMediaClient.Models.Requests.Comment
{
    public class CreateCommentRequest
    {
        public Guid UserID { get; set; }

        public Guid EntryID { get; set; }

        public Guid ParentCommentID { get; set; }

        public string CommentString { get; set; }

    }
}
