﻿using SocialMediaClient.Models.Enums;

namespace SocialMediaClient.Models.Requests.EntryVote
{
    public class CreateEntryVoteRequest
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
        public VoteType VoteType { get; set; }
    }
}
