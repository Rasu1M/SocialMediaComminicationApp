﻿namespace SocialMediaClient.Models.Requests
{
    public class DeleteEntryVoteRequest
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
    }
}
