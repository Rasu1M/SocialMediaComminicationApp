﻿namespace SocialMediaClient.Models.Requests.AccountManagement
{
    public class LoginRequest
    {
        public string Email { get; set; }

        public string PassWord { get; set; }
    }
}
