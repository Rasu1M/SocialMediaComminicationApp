﻿namespace SocialMediaClient.Models.Requests.AccountManagement
{
    public class ChangeUsernameRequest
    {
        public Guid UserID { get; set; }
        public string NewFullName { get; set; }
    }
}
