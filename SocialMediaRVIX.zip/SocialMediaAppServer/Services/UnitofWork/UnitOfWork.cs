﻿

using SocialMediaAppServer.DataBase;
using SocialMediaAppServer.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MindMaze.Infrastructure.infrastructure.Services
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly SocialMediaDBContext _dbContext;

        public UnitOfWork(SocialMediaDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int SaveChanges()
        {
            return _dbContext.SaveChanges();
        }

        public async Task<int> SaveChangesAsync()
        {
            return await _dbContext.SaveChangesAsync();
        }
    }
}
