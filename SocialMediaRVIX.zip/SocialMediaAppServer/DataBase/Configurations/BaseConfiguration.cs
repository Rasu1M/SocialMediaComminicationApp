﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;

namespace SocialMediaAppServer.DataBase.Configurations
{
    public class BaseConfiguration<Tentity> : IEntityTypeConfiguration<Tentity> where Tentity : BaseClass
    {
        public virtual void Configure(EntityTypeBuilder<Tentity> builder)
        {
            builder.HasKey(x => x.ID);
        }
    }
}