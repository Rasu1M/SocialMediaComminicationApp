﻿using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;
using System.Reflection;

namespace SocialMediaAppServer.DataBase
{
    public class SocialMediaDBContext : DbContext
    {


        public SocialMediaDBContext()
        {

        }

        public SocialMediaDBContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }

        public DbSet<Entry> Entries { get; set; } 

        public DbSet<EntryVote> EntryVotes { get; set; }

        public DbSet<Comment> Comments { get; set; }

        public DbSet<CommentVote> CommentVotes { get; set; }


    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                var connecstr = "Data Source=RASUL\\SQLEXPRESS;Initial Catalog=SocialMediaX;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

                optionsBuilder.UseSqlServer(connecstr, op =>
                {
                    op.EnableRetryOnFailure();
                    op.CommandTimeout(100);
                });
            }
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
        }
    }
}