﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialMediaAppServer.Features.Commands.User.Create;
using SocialMediaAppServer.Features.Commands.User.Update.UpdatePassWord;
using SocialMediaAppServer.Features.Commands.User.Update.UpdateUsername;
using SocialMediaAppServer.Features.Queries.User.LogIn;
using SocialMediaAppServer.Models.Responses.UserResponses;

namespace SocialMediaAppServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountManagementController : ControllerBase
    {
        private readonly IMediator _mediator;

        public AccountManagementController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        [Route("/LogIn")]
        public async Task<IActionResult> LogIn([FromQuery] LogInRequest request)
        {
            
            var response = await _mediator.Send<GetUserLoginInfoResponse>(request);

           return Ok(response);
        }

        [HttpGet]
        [Route("/SignUp")]
        public async Task<IActionResult> SignUp([FromQuery] CreateUserRequest request)//string FullName, string Email, string PassWord)
        {
           /* var request = new CreateUserRequest()
            {
                FullName = FullName,
                Email = Email,
                Password = PassWord
            };*/

            var response = await _mediator.Send<Guid>(request);

            return Ok(response);
        }


        [HttpPost]
        [Route("/ChangePassWord")]
        public async Task<IActionResult> ChangePassword([FromBody] UpdatePassWordRequest request) // string OldPassword, string NewPassword)
        {
            /*var request = new UpdatePassWordRequest()
            {
                OldPassWord = OldPassword,
                NewPassWord = NewPassword
            };
*/
            var response = await _mediator.Send<bool>(request);

            return Ok(response);

        }

        [HttpPost]
        [Route("/ChangeFullName")]
        public async Task<IActionResult> ChangeFullName([FromBody] UpdateFullNameRequest request) // string newFullName)
        {
            /*var request = new UpdateFullNameRequest()
            {
                NewFullName = newFullName
            };*/

            var response = await _mediator.Send<bool>(request);

            return Ok(response);
        }


    }
}
