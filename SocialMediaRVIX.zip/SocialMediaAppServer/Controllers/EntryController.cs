﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialMediaAppServer.Features.Commands.CommentVote.Create;
using SocialMediaAppServer.Features.Commands.CommentVote.Delete;
using SocialMediaAppServer.Features.Commands.Entry.Create;
using SocialMediaAppServer.Features.Commands.EntryVote.Create;
using SocialMediaAppServer.Features.Commands.EntryVote.Delete;
using SocialMediaAppServer.Features.Queries.Entry;
using SocialMediaAppServer.Models.Responses.EntryResponses;

namespace SocialMediaAppServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EntryController : ControllerBase
    {
        private readonly IMediator _mediator;

        public EntryController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("/AddEntry")]
        public async Task<Guid> AddEntry([FromBody]CreateEntryRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }


        [HttpGet]
        [Route("/GetEntries")]
        public async Task<GetEntriesResponse> GetEntries([FromQuery] GetEntriesRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpGet]
        [Route("/GetEntriesRandomly")]
        public async Task<GetEntriesResponse> GetEntriesRandomly([FromQuery] GetEntriesRandomlyRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpPost]
        [Route("/AddEntryVote")]
        public async Task<bool> AddEntryVote([FromBody] CreateEntryVoteRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpPost]
        [Route("/DeleteEntryVote")]
        public async Task<bool> DeleteEntryVote([FromBody] DeleteEntryVoteRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }
    }
}
