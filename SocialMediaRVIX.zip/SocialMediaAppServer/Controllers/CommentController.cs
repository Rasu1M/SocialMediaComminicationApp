﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SocialMediaAppServer.Features.Commands.Comment.Create;
using SocialMediaAppServer.Features.Commands.CommentVote.Create;
using SocialMediaAppServer.Features.Commands.CommentVote.Delete;
using SocialMediaAppServer.Features.Commands.Entry.Create;
using SocialMediaAppServer.Features.Queries.Comment;
using SocialMediaAppServer.Features.Queries.Entry;
using SocialMediaAppServer.Models.Responses.CommentResponses;
using SocialMediaAppServer.Models.Responses.EntryResponses;

namespace SocialMediaAppServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommentController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CommentController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpPost]
        [Route("/AddComment")]
        public async Task<bool> AddComment([FromBody] CreateCommentRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpGet]
        [Route("/GetComments")]
        public async Task<GetCommentsForTheEntryResponse> GetComments([FromQuery] GetAllCommentsForTheEntryRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpPost]
        [Route("/AddCommentVote")]
        public async Task<bool> AddCommentVote([FromBody] CreateCommentVoteRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }

        [HttpPost]
        [Route("/DeleteCommentVote")]
        public async Task<bool> DeleteCommentVote([FromBody] DeleteCommentVoteRequest request)
        {
            var response = await _mediator.Send(request);

            return response;
        }
    }
}
