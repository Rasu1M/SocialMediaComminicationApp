﻿using Blazored.LocalStorage;
using MediatR;
using Microsoft.AspNetCore.Identity.Data;
using MindMaze.Infrastructure.infrastructure.Repositories;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.Responses.UserResponses;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Queries.User.LogIn
{
    public class LogInRequestHandler : IRequestHandler<LogInRequest, GetUserLoginInfoResponse>
    {
        private readonly IReadGenericRepository<Users> _readRepository;

        public LogInRequestHandler(IReadGenericRepository<Users> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<GetUserLoginInfoResponse> Handle(LogInRequest request, CancellationToken cancellationToken)
        {
            var User = await _readRepository.Getasync(x => x.Email == request.Email 
            && x.Password == request.PassWord);

            if (User == null)
            {
                return new GetUserLoginInfoResponse()
                {
                    UserId = Guid.Empty,
                    FullName = "UnKnown",
                    Email = "Unknown"
                };
            }

            if (User.IsDeleted)
            {
                return new GetUserLoginInfoResponse()
                {
                    UserId = Guid.Empty,
                    FullName = "UnKnown",
                    Email = "Unknown"
                };
            }


            return new GetUserLoginInfoResponse()
            {
                UserId = User.ID,
                FullName = User.FullName,
                Email = User.Email
            };

        }
    }
}
