﻿using MediatR;
using SocialMediaAppServer.Models.Responses.UserResponses;

namespace SocialMediaAppServer.Features.Queries.User.LogIn
{
    public class LogInRequest : IRequest<GetUserLoginInfoResponse>
    {
        public string Email { get; set; }

        public string PassWord { get; set; }
    }
}
