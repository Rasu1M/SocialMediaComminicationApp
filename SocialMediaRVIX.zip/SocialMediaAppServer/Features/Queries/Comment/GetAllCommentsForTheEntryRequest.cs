﻿using MediatR;
using SocialMediaAppServer.Models.Responses.CommentResponses;

namespace SocialMediaAppServer.Features.Queries.Comment
{
    public class GetAllCommentsForTheEntryRequest : IRequest<GetCommentsForTheEntryResponse>
    {
        public Guid EntryID { get; set; }
    }
}
