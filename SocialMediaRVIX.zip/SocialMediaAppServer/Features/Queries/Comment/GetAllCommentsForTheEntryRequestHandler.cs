﻿using Azure.Core;
using Azure;
using MediatR;
using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.DTOs;
using SocialMediaAppServer.Models.Enums;
using SocialMediaAppServer.Models.Strctures;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using System.Collections.Generic;
using SocialMediaAppServer.Models.Responses.CommentResponses;

namespace SocialMediaAppServer.Features.Queries.Comment
{
    public class GetAllCommentsForTheEntryRequestHandler : IRequestHandler<GetAllCommentsForTheEntryRequest,
        GetCommentsForTheEntryResponse>
    {
        private readonly IReadGenericRepository<Models.Domain.Entry> _entryreadRepository;
        private readonly IReadGenericRepository<Models.Domain.Comment> _readRepository;

        public GetAllCommentsForTheEntryRequestHandler(IReadGenericRepository<Models.Domain.Entry> entryreadRepository,
                                                       IReadGenericRepository<Models.Domain.Comment> readRepository)
        {
            _entryreadRepository = entryreadRepository;
            _readRepository = readRepository;
        }

        public async Task<GetCommentsForTheEntryResponse> Handle(GetAllCommentsForTheEntryRequest request, CancellationToken cancellationToken)
        {
            var response = new GetCommentsForTheEntryResponse();

            response.Entry = GetEntry(request.EntryID);

            if(response.Entry == null)
            {
                return response;
            }

            response.Comments = GetCommentStructure(request.EntryID);
           
            return response;

        }

        private List<CommentsStructure> GetCommentStructure(Guid EntryID)
        {
            var comments = _readRepository.AsQueryable().Where(x => x.EntryID == EntryID)
               .Include(x => x.CommentVotes).Include(x => x.User).ToList();

            List<CommentsStructure> commentsStructures = new List<CommentsStructure>();

            if (comments != null && comments.Count > 0)
            {
                // ADD Comments TO commentStructures
                foreach (var comment in comments)
                {
                    int upVotes = 0;

                    int downVotes = 0;

                    if (comment.CommentVotes != null && comment.CommentVotes.Count > 0)
                    {

                        // ADD COMMENT VOTES FOR EVERY COMMENT
                        foreach (var commentVote in comment.CommentVotes)
                        {
                            if (commentVote.VoteType == VoteType.UpVote)
                            {
                                upVotes++;
                            }

                            if (commentVote.VoteType == VoteType.DownVote)
                            {
                                downVotes++;
                            }

                        }

                    }

                    var commentDTO = new CommentDTO()
                    {
                        UserID = comment.UserID,
                        EntryID = comment.EntryID,
                        CommentID = comment.ID,
                        ParentCommentID = comment.ParentCommentID,
                        CommentString = comment.CommentString,
                        UpVotes = upVotes,
                        DownVotes = downVotes,
                        UserInfo = new UserInfoDTO()
                        {
                            UserID = comment.User.ID,
                            FullName = comment.User.FullName
                        }

                    };

                    CommentsStructure commentsStructure = new CommentsStructure()
                    {
                        Comment = commentDTO,
                        ChildrenComments = new List<CommentsStructure>()
                    };

                    commentsStructures.Add(commentsStructure);
                }
            }



            var commentMap = new Dictionary<Guid, List<CommentsStructure>>();

            List<CommentsStructure> Result = new List<CommentsStructure>();

            if (commentsStructures != null && commentsStructures.Count > 0)
            {
                foreach (var commentStructure in commentsStructures)
                {
                    //ADD FIRST CHILDREN OF THE ENTRY TO THE RESPONSE COMMENTS
                    if (commentStructure.Comment.ParentCommentID == Guid.Empty)
                    {
                        CommentsStructure commentstructure = new CommentsStructure()
                        {
                            Comment = commentStructure.Comment,
                            ChildrenComments = new List<CommentsStructure>()
                        };


                        Result.Add(commentstructure);
                    }
                    else
                    {
                        // ADD CHILDCOMMENTS TO MAP
                        if (!commentMap.ContainsKey(commentStructure.Comment.ParentCommentID))
                        {
                            commentMap[commentStructure.Comment.ParentCommentID] = new List<CommentsStructure>();
                        }
                        commentMap[commentStructure.Comment.ParentCommentID].Add(commentStructure);
                    }
                }
            }

            if (Result != null && Result.Count > 0)
            {

                // ADD CHILD COMMENTS TO THEIR RESPECTIVE PARENT COMMENTS
                foreach (var responsecomments in Result)
                {
                    AddChildComments(responsecomments, commentMap);
                }
            }

            return Result;

        }

        private EntryDTO GetEntry(Guid EntryID)
        {
            var entry = _entryreadRepository.AsQueryable().Where(x => x.ID == EntryID)
                .Include(x => x.User).Include(x => x.EntryVotes)
                .Include(x => x.Comments).Include(x => x.CommentVotes).FirstOrDefault();

            if (entry == null)
            {
                return null;
            }

            int upVotes = 0;
            int downVotes = 0;
            int commentsUpVotes = 0;
            int commentsDownVotes = 0;

            if (entry.EntryVotes != null && entry.EntryVotes.Count > 0)
            {

                // ADD ENTRYVOTES OF EVERY ENTRY TO RESPONSE
                foreach (var entryVote in entry.EntryVotes)
                {
                    if (entryVote.VoteType == VoteType.UpVote)
                    {
                        upVotes++;
                    }

                    if (entryVote.VoteType == VoteType.DownVote)
                    {
                        downVotes++;
                    }

                }
            }

            if (entry.CommentVotes != null && entry.CommentVotes.Count > 0)
            {

                //ADD TOTALVOTES FOR COMMENTS OF EVERY ENTRY TO RESPONSE
                foreach (var commentVote in entry.CommentVotes)
                {
                    if (commentVote.VoteType == VoteType.UpVote)
                    {
                        commentsUpVotes++;
                    }

                    if (commentVote.VoteType == VoteType.DownVote)
                    {
                        commentsDownVotes++;
                    }

                }
            }

            // CREATE ENTRYDTO FOR THE RESPONSE's ENTRY
            return new EntryDTO()
            {
                EntryID = entry.ID,
                EntryTitle = entry.EntryTitle,
                EntryTopic = entry.EntryTopic,
                UpVotes = upVotes,
                DownVotes = downVotes,
                CommentsUpVotes = commentsUpVotes,
                CommentsDownVotes = commentsDownVotes,
                TotalComments = entry.Comments.Count(),
                UserInfo = new UserInfoDTO()
                {
                    UserID = entry.User.ID,
                    FullName = entry.User.FullName,
                }

            };
        }

        private void AddChildComments(CommentsStructure parentComment, Dictionary<Guid, List<CommentsStructure>> commentMap)
        {
            if (commentMap.ContainsKey(parentComment.Comment.CommentID))
            {
                parentComment.ChildrenComments.AddRange(commentMap[parentComment.Comment.CommentID]);

                if (parentComment.ChildrenComments != null
                    && parentComment.ChildrenComments.Count > 0)
                {
                    foreach (var childComment in parentComment.ChildrenComments)
                    {
                        AddChildComments(childComment, commentMap);
                    }
                }
            }

        }
    }
}
