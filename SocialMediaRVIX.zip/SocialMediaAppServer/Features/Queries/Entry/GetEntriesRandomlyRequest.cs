﻿using MediatR;
using SocialMediaAppServer.Models.Responses.EntryResponses;

namespace SocialMediaAppServer.Features.Queries.Entry
{
    public class GetEntriesRandomlyRequest : IRequest<GetEntriesResponse>
    {
    }
}
