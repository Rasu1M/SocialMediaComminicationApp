﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Models.DTOs;
using SocialMediaAppServer.Models.Enums;
using SocialMediaAppServer.Models.Responses.EntryResponses;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using System.Security.Cryptography;

namespace SocialMediaAppServer.Features.Queries.Entry
{
    public class GetEntriesRandomlyRequestHandler : IRequestHandler<GetEntriesRandomlyRequest, GetEntriesResponse>
    {
        private readonly IReadGenericRepository<Models.Domain.Entry> _readRepository;

        public GetEntriesRandomlyRequestHandler(IReadGenericRepository<Models.Domain.Entry> readRepository)
        {
            _readRepository = readRepository;
        }

        public async Task<GetEntriesResponse> Handle(GetEntriesRandomlyRequest request, CancellationToken cancellationToken)
        {
            List<Models.Domain.Entry> entries = _readRepository.AsQueryable()
                .OrderBy(x => RandomNumberGenerator.GetInt32(200)).Take(100)
                .Include(x => x.User).Include(x => x.EntryVotes)
                .Include(x => x.Comments).Include(x => x.CommentVotes).ToList();

            GetEntriesResponse response = new GetEntriesResponse();

            if (entries.Count > 0)
            {

                // ADD ENTRIES TO THE RESPONSE
                foreach (var entry in entries)
                {
                    int upVotes = 0;
                    int downVotes = 0;
                    int commentsUpVotes = 0;
                    int commentsDownVotes = 0;

                    if (entry.EntryVotes != null && entry.EntryVotes.Count > 0)
                    {

                        // ADD ENTRYVOTES OF EVERY ENTRY TO RESPONSE
                        foreach (var entryVote in entry.EntryVotes)
                        {
                            if (entryVote.VoteType == VoteType.UpVote)
                            {
                                upVotes++;
                            }

                            if (entryVote.VoteType == VoteType.DownVote)
                            {
                                downVotes++;
                            }

                        }
                    }

                    if (entry.CommentVotes != null && entry.CommentVotes.Count > 0)
                    {

                        //ADD TOTALVOTES FOR COMMENTS OF EVERY ENTRY TO RESPONSE
                        foreach (var commentVote in entry.CommentVotes)
                        {
                            if (commentVote.VoteType == VoteType.UpVote)
                            {
                                commentsUpVotes++;
                            }

                            if (commentVote.VoteType == VoteType.DownVote)
                            {
                                commentsDownVotes++;
                            }

                        }
                    }

                    // CREATE ENTRYDTO FOR EVERY ENTRY
                    var entryDTO = new EntryDTO()
                    {
                        EntryID = entry.ID,
                        EntryTitle = entry.EntryTitle,
                        EntryTopic = entry.EntryTopic,
                        UpVotes = upVotes,
                        DownVotes = downVotes,
                        CommentsUpVotes = commentsUpVotes,
                        CommentsDownVotes = commentsDownVotes,
                        TotalComments = entry.Comments.Count(),
                        UserInfo = new UserInfoDTO()
                        {
                            UserID = entry.User.ID,
                            FullName = entry.User.FullName,
                        }

                    };

                    response.Entries.Add(entryDTO);
                }
            }

            return response;
        }
    }
}
