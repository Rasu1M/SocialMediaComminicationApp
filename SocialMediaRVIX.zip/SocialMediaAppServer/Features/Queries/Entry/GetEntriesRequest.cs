﻿using MediatR;
using SocialMediaAppServer.Models.Enums;
using SocialMediaAppServer.Models.Responses.EntryResponses;

namespace SocialMediaAppServer.Features.Queries.Entry
{
    public class GetEntriesRequest : IRequest<GetEntriesResponse>
    {
        public EntryTypes EntryType { get; set; }

        public WriterType WriterType { get; set; }
    }
}
