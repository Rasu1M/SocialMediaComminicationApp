﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;

namespace SocialMediaAppServer.Features.Commands.CommentVote.Delete
{
    public class DeleteCommentVoteRequestHandler : IRequestHandler<DeleteCommentVoteRequest, bool>
    {
        private readonly IGenericRepository<Models.Domain.CommentVote> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteCommentVoteRequestHandler(IGenericRepository<Models.Domain.CommentVote> genericRepository,
                                               IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(DeleteCommentVoteRequest request, CancellationToken cancellationToken)
        {
           

            var CommentVote = await _genericRepository
                .Getasync(x => x.CommentID == request.CommentID && x.UserID == request.UserID);

            _genericRepository.Delete(CommentVote);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;
        }
    }
}
