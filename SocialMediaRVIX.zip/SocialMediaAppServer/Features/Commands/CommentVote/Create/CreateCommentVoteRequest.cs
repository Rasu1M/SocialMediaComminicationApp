﻿using MediatR;
using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Features.Commands.CommentVote.Create
{
    public class CreateCommentVoteRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
        public Guid CommentID { get; set; }
        public VoteType VoteType { get; set; }
    }
}
