﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.EntryVote.Delete
{
    public class DeleteEntryVoteRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
    }
}
