﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Features.Commands.CommentVote.Delete;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;

namespace SocialMediaAppServer.Features.Commands.EntryVote.Delete
{
    public class DeleteEntryVoteRequestHandler : IRequestHandler<DeleteEntryVoteRequest, bool>
    {
        private readonly IGenericRepository<Models.Domain.EntryVote> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public DeleteEntryVoteRequestHandler(IGenericRepository<Models.Domain.EntryVote> genericRepository,
                                             IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(DeleteEntryVoteRequest request, CancellationToken cancellationToken)
        {
            

            var CommentVote = await _genericRepository.Getasync(x => x.EntryID == request.EntryID && x.UserID == request.UserID);
            _genericRepository.Delete(CommentVote);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;
        }
    }
}
