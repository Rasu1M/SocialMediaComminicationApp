﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Features.Commands.CommentVote.Create;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;

namespace SocialMediaAppServer.Features.Commands.EntryVote.Create
{
    public class CreateEntryVoteRequestHandler : IRequestHandler<CreateEntryVoteRequest, bool>
    {
        private readonly IWriteGenericRepository<Models.Domain.EntryVote> _writeRepository;
        private readonly IReadGenericRepository<Models.Domain.EntryVote> _readRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateEntryVoteRequestHandler(IWriteGenericRepository<Models.Domain.EntryVote> writeRepository,
                                             IReadGenericRepository<Models.Domain.EntryVote> readRepository,
                                             IUnitOfWork unitOfWork)
        {
            _writeRepository = writeRepository;
            _readRepository = readRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(CreateEntryVoteRequest request, CancellationToken cancellationToken)
        {


            if (await _readRepository.Getasync(x => x.UserID == request.UserID
                && x.EntryID == request.EntryID) != null)
            {
                return false;
            }

            Models.Domain.EntryVote entryvote = new Models.Domain.EntryVote()
            {
                UserID = request.UserID,
                EntryID = request.EntryID,
                VoteType = request.VoteType
            };

            await _writeRepository.Addasync(entryvote);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
