﻿using MediatR;
using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Features.Commands.EntryVote.Create
{
    public class CreateEntryVoteRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
        public VoteType VoteType { get; set; }
    }
}
