﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.User.Delete
{
    public class SetUserDeletionRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }
    }
}
