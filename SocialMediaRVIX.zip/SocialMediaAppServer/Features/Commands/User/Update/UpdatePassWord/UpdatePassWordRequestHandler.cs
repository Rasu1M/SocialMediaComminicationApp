﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Commands.User.Update.UpdatePassWord
{
    public class UpdatePassWordRequestHandler : IRequestHandler<UpdatePassWordRequest, bool>
    {
        private readonly IGenericRepository<Users> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public UpdatePassWordRequestHandler(IGenericRepository<Users> genericRepository, IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<bool> Handle(UpdatePassWordRequest request, CancellationToken cancellationToken)
        {
            

            var user = await _genericRepository.Getasync(x => x.ID == request.UserID && x.Password == request.OldPassWord);

            if (user == null)
            {
                return false;
            }

            user.Password = request.NewPassWord;

            _genericRepository.UpdateEntity(user);

            if (await _unitOfWork.SaveChangesAsync() == 1) return true;

            return false;

        }
    }
}
