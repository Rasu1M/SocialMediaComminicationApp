﻿using Blazored.LocalStorage;
using MediatR;
using SocialMediaAppServer.Models.Domain;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;

namespace SocialMediaAppServer.Features.Commands.User.Create
{
    public class CreateUserRequestHandler : IRequestHandler<CreateUserRequest, Guid>
    {
        private readonly IGenericRepository<Users> _genericRepository;
        private readonly IUnitOfWork _unitOfWork;

        public CreateUserRequestHandler(IGenericRepository<Users> genericRepository, IUnitOfWork unitOfWork)
        {
            _genericRepository = genericRepository;
            _unitOfWork = unitOfWork;
        }

        public async Task<Guid> Handle(CreateUserRequest request, CancellationToken cancellationToken)
        {
            

           var User = await _genericRepository.Getasync(x => x.Email == request.Email);

            if (User != null) return Guid.Empty;
                
            User = new Users()
            {
                ID = Guid.NewGuid(),

                FullName = request.FullName,

                Email = request.Email,

                Password = request.Password,

                IsDeleted = false
            };

            await _genericRepository.Addasync(User);

            if (await _unitOfWork.SaveChangesAsync() == 1)
            {

                return User.ID;
            }

            else return Guid.Empty;

        }
    }
}
