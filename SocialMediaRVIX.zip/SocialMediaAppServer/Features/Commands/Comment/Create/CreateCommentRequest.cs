﻿using MediatR;

namespace SocialMediaAppServer.Features.Commands.Comment.Create
{
    public class CreateCommentRequest : IRequest<bool>
    {
        public Guid UserID { get; set; }

        public Guid EntryID { get; set; }

        public Guid ParentCommentID { get; set; }

        public string CommentString { get; set; }

    }
}
