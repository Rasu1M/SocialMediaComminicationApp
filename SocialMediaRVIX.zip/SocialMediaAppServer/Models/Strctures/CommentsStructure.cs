﻿using SocialMediaAppServer.Models.DTOs;

namespace SocialMediaAppServer.Models.Strctures
{
    public struct CommentsStructure
    {
        public CommentDTO Comment { get; set; }

        public List<CommentsStructure> ChildrenComments { get; set; }
    }
}
