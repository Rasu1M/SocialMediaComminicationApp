﻿namespace SocialMediaAppServer.Models.Enums
{
    public enum WriterType
    {
        All = 0,
        System = 1,
        User = 2
    }
}
