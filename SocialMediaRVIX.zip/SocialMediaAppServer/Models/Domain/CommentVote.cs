﻿using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Models.Domain
{
    public class CommentVote : BaseClass
    {
        public Guid UserID { get; set; }
        public Guid EntryID { get; set; }
        public Guid CommentID { get; set; }
        public VoteType VoteType { get; set; }

        public Users User { get; set; }
        public Entry Entry { get; set; }
        public Comment Comment { get; set; }

    }
}
