﻿namespace SocialMediaAppServer.Models.Domain
{
    public class Comment : BaseClass
    {
        public Guid UserID { get; set; }

        public Guid EntryID { get; set; }

        public Guid ParentCommentID { get; set; }

        public string CommentString { get; set; }

        public Users User { get; set; }

        public Entry Entry { get; set; }

        public ICollection<CommentVote> CommentVotes { get; set; }
    }
}
