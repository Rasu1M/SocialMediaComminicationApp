﻿using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Models.Domain
{
    public class Entry : BaseClass
    {
        public Guid UserID { get; set; }

        public string EntryTitle { get; set; }

        public string EntryTopic { get; set; }

        public bool IsWritedBySystem { get; set; }

        public EntryTypes EntryType { get; set; }

        public Users User { get; set; }
        public ICollection<Comment> Comments { get; set; }
        public ICollection<EntryVote> EntryVotes { get; set; }
        public ICollection<CommentVote> CommentVotes { get; set; }


    }
}
