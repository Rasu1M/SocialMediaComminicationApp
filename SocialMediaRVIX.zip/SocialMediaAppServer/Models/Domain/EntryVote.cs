﻿using SocialMediaAppServer.Models.Enums;

namespace SocialMediaAppServer.Models.Domain
{
    public class EntryVote : BaseClass
    {
        public Guid EntryID { get; set; }

        public Guid UserID { get; set; }

        public VoteType VoteType { get; set;}

        public Users User { get; set; }
        public Entry Entry { get; set; }
    }
}
