﻿namespace SocialMediaAppServer.Models.Domain
{
    public class Users : BaseClass
    {
        public string FullName { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public bool IsDeleted { get; set; }

        public ICollection<Entry> Entries { get; set; }

        public ICollection<EntryVote> EntryVotes { get; set; }

        public ICollection<Comment> Comments { get; set; }

        public ICollection<CommentVote> CommentVotes { get; set; }
    }
}
