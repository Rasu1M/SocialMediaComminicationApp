﻿using SocialMediaAppServer.Models.DTOs;

namespace SocialMediaAppServer.Models.Responses.EntryResponses
{
    public class GetEntriesResponse
    {
        public List<EntryDTO> Entries { get; set; } = new List<EntryDTO>();
    }
}
