﻿using Microsoft.EntityFrameworkCore;
using MindMaze.Infrastructure.infrastructure.Repositories;
using MindMaze.Infrastructure.infrastructure.Services;
using SocialMediaAppServer.Services.Interfaces.IGenericRepositories;
using SocialMediaAppServer.Services.Interfaces;
using SocialMediaAppServer.DataBase.Interceptors;
using SocialMediaAppServer.DataBase;

namespace SocialMediaAppServer.Registrations.DatabaseRegistration
{
    public static class DatabaseRegistration
    {

        public static IServiceCollection RegisterToDatabase(this IServiceCollection Services, IConfiguration configuration)
        {


            Services.AddDbContext<SocialMediaDBContext>(sp =>
            {

                var connstr = configuration["ConnectionStrings:SocialMediaApp"];
                

                sp.UseSqlServer(connstr, op =>
                {
                    op.EnableRetryOnFailure();
                    op.CommandTimeout(100);
                });

                sp.AddInterceptors(new CustomDatabaseModifyInterceptor());

                sp.EnableDetailedErrors(true);
                //TODO change this after
                sp.EnableSensitiveDataLogging(true);
            });

            // Services.AddScoped<DbContext, SocialMediaDBContext>();

            Services.AddTransient(typeof(IReadGenericRepository<>), typeof(ReadRepository<>));

            Services.AddTransient(typeof(IWriteGenericRepository<>), typeof(WriteRepository<>));

            Services.AddTransient(typeof(IGenericRepository<>), typeof(GenericRepository<>));

            Services.AddTransient<IUnitOfWork, UnitOfWork>();






            return Services;
        }
    }
}